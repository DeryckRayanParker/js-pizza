$(document).ready(function(){
 	 var val;
		
		$('#registration-form').validate({
		rules: {
		 inputName: {
			required: true,
	        digits: true
	      },
		  
		 inputPhone: {
			required: true,
			dateISO: true
			},
		  
		 inputAdress: {
	        required: true
	      }
			},
										 
			highlight: function(element) {
			$(element).closest('#rules').removeClass('has-success').addClass('has-error');
				$(element).closest('.control-group').removeClass('success').addClass('error');
			},
			success: function(element) {
				element
				.text('OK!').addClass('valid')
				.closest('.control-group').removeClass('error').addClass('success');
				$(element).closest('#rules').removeClass('has-error').addClass('has-success');
			}
	  });
			
	
}); // end document.ready