/**
 * Created by chaika on 25.01.16.
 */

$(function(){
    //This code will execute when the page is ready
    var PizzaMenu = require('./pizza/PizzaMenu');
    var PizzaCart = require('./pizza/PizzaCart');
    var Pizza_List = require('./Pizza_List');
	var API = require('./API');
	
	
	function base64(str) { 
		return new Buffer(str).toString('base64'); 
	}
	
	var crypto = require('crypto'); 
	
	function sha1(string) { 
		var sha1 = crypto.createHash('sha1'); 
		sha1.update(string); 
		return sha1.digest('base64'); 
	}
	
    PizzaCart.initialiseCart();
    PizzaMenu.initialiseMenu();
function createOrder(callback) {
		var nameCustomer = $('#inputName').val();
		var phoneCustomer = $('#inputPhone').val();
		var addressCustomer = $('#inputAdress').val();
		var priceCustomer = PizzaCart.getSum();
		var pizzaCustomer = PizzaCart.getPizzaInCart();
		
		var customer_data = {
			name: nameCustomer,
			phone: phoneCustomer,
			address: addressCustomer,
			payAmount: priceCustomer,
			pizza_list: pizzaCustomer
		}
		
		API.createOrder(customer_data, function(err, user_data){ 
			if(!err) { 
				callback(null, user_data);
			} else {
				return	callback(err);
			}
		});
	}
	
	$(".postButton").click(function(){
		
		createOrder(function(err, user_data) { 
			if(err)	{ 
				return callback(err); 
			}
			
			LiqPayCheckout.init({
				data: user_data.data,
				signature: user_data.signature,
				embedTo: "#liqpay",
				mode: "popup" // embed || popup
			}).on("liqpay.callback", function(data){
				console.log(data.status);
				console.log(data);
			}).on("liqpay.ready", function(data){
				// ready
			}).on("liqpay.close", function(data){
				// close
			});
	        
		});
	});
});